package com.mesanger.copy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import androidx.cardview.widget.CardView;
import android.content.Intent;
import android.net.Uri;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import com.blogspot.atifsoftwares.animatoolib.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class ChatActivity extends AppCompatActivity {
	
	private LinearLayout linear2;
	private LinearLayout linear5;
	private LinearLayout internet;
	private LinearLayout lin_search;
	private LinearLayout background;
	private LinearLayout linear4;
	private CircleImageView circleimageview1;
	private TextView textview1;
	private ImageView cam;
	private ImageView edit;
	private ImageView txt_int;
	private ImageView imageview3;
	private EditText edittext1;
	private LinearLayout lin1;
	private LinearLayout lin2;
	private LinearLayout lin3;
	private HorizontalScrollView hscroll1;
	private ScrollView vscroll1;
	private LinearLayout linear6;
	private LinearLayout linear12;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private CircleImageView circleimageview2;
	private TextView textview2;
	private CircleImageView circleimageview3;
	private TextView textview3;
	private CircleImageView circleimageview4;
	private TextView textview4;
	private CircleImageView circleimageview5;
	private TextView textview5;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear53;
	private CircleImageView circleimageview6;
	private LinearLayout linear17;
	private CircleImageView circleimageview10;
	private TextView textview6;
	private LinearLayout linear21;
	private TextView textview10;
	private TextView textview11;
	private CircleImageView circleimageview7;
	private LinearLayout linear18;
	private CircleImageView circleimageview11;
	private TextView textview7;
	private LinearLayout linear22;
	private TextView textview12;
	private TextView textview13;
	private CircleImageView circleimageview8;
	private LinearLayout linear19;
	private CircleImageView circleimageview12;
	private TextView textview8;
	private LinearLayout linear23;
	private TextView textview14;
	private TextView textview15;
	private CircleImageView circleimageview9;
	private LinearLayout linear20;
	private CircleImageView circleimageview13;
	private TextView textview9;
	private LinearLayout linear25;
	private TextView textview16;
	private TextView textview17;
	private LinearLayout linear28;
	private LinearLayout linear39;
	private LinearLayout linear41;
	private LinearLayout linear43;
	private LinearLayout linear34;
	private TextView textview18;
	private CircleImageView circleimageview18;
	private CircleImageView point1;
	private LinearLayout linear40;
	private TextView textview25;
	private CircleImageView circleimageview23;
	private CircleImageView poin2;
	private LinearLayout linear42;
	private TextView textview26;
	private CircleImageView circleimageview25;
	private CircleImageView point3;
	private LinearLayout linear44;
	private TextView textview27;
	private CircleImageView circleimageview27;
	private CircleImageView point4;
	private ScrollView vscroll2;
	private LinearLayout linear46;
	private LinearLayout linear47;
	private CardView cardview1;
	private CardView cardview2;
	private RelativeLayout s1;
	private ImageView imageview4;
	private ImageView add;
	private LinearLayout linear51;
	private TextView textview28;
	private RelativeLayout s2;
	private ImageView imageview5;
	private CircleImageView c1;
	private LinearLayout linear52;
	private TextView textview29;
	private LinearLayout b1;
	private LinearLayout b2;
	private LinearLayout b3;
	
	private Intent face = new Intent();
	private Intent insta = new Intent();
	private Intent i = new Intent();
	private AlertDialog.Builder d1;
	private Intent chat = new Intent();
	private FragmentStatePagerAdapter frag;
	private Intent search = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		linear5 = findViewById(R.id.linear5);
		internet = findViewById(R.id.internet);
		lin_search = findViewById(R.id.lin_search);
		background = findViewById(R.id.background);
		linear4 = findViewById(R.id.linear4);
		circleimageview1 = findViewById(R.id.circleimageview1);
		textview1 = findViewById(R.id.textview1);
		cam = findViewById(R.id.cam);
		edit = findViewById(R.id.edit);
		txt_int = findViewById(R.id.txt_int);
		imageview3 = findViewById(R.id.imageview3);
		edittext1 = findViewById(R.id.edittext1);
		lin1 = findViewById(R.id.lin1);
		lin2 = findViewById(R.id.lin2);
		lin3 = findViewById(R.id.lin3);
		hscroll1 = findViewById(R.id.hscroll1);
		vscroll1 = findViewById(R.id.vscroll1);
		linear6 = findViewById(R.id.linear6);
		linear12 = findViewById(R.id.linear12);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		linear15 = findViewById(R.id.linear15);
		circleimageview2 = findViewById(R.id.circleimageview2);
		textview2 = findViewById(R.id.textview2);
		circleimageview3 = findViewById(R.id.circleimageview3);
		textview3 = findViewById(R.id.textview3);
		circleimageview4 = findViewById(R.id.circleimageview4);
		textview4 = findViewById(R.id.textview4);
		circleimageview5 = findViewById(R.id.circleimageview5);
		textview5 = findViewById(R.id.textview5);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear53 = findViewById(R.id.linear53);
		circleimageview6 = findViewById(R.id.circleimageview6);
		linear17 = findViewById(R.id.linear17);
		circleimageview10 = findViewById(R.id.circleimageview10);
		textview6 = findViewById(R.id.textview6);
		linear21 = findViewById(R.id.linear21);
		textview10 = findViewById(R.id.textview10);
		textview11 = findViewById(R.id.textview11);
		circleimageview7 = findViewById(R.id.circleimageview7);
		linear18 = findViewById(R.id.linear18);
		circleimageview11 = findViewById(R.id.circleimageview11);
		textview7 = findViewById(R.id.textview7);
		linear22 = findViewById(R.id.linear22);
		textview12 = findViewById(R.id.textview12);
		textview13 = findViewById(R.id.textview13);
		circleimageview8 = findViewById(R.id.circleimageview8);
		linear19 = findViewById(R.id.linear19);
		circleimageview12 = findViewById(R.id.circleimageview12);
		textview8 = findViewById(R.id.textview8);
		linear23 = findViewById(R.id.linear23);
		textview14 = findViewById(R.id.textview14);
		textview15 = findViewById(R.id.textview15);
		circleimageview9 = findViewById(R.id.circleimageview9);
		linear20 = findViewById(R.id.linear20);
		circleimageview13 = findViewById(R.id.circleimageview13);
		textview9 = findViewById(R.id.textview9);
		linear25 = findViewById(R.id.linear25);
		textview16 = findViewById(R.id.textview16);
		textview17 = findViewById(R.id.textview17);
		linear28 = findViewById(R.id.linear28);
		linear39 = findViewById(R.id.linear39);
		linear41 = findViewById(R.id.linear41);
		linear43 = findViewById(R.id.linear43);
		linear34 = findViewById(R.id.linear34);
		textview18 = findViewById(R.id.textview18);
		circleimageview18 = findViewById(R.id.circleimageview18);
		point1 = findViewById(R.id.point1);
		linear40 = findViewById(R.id.linear40);
		textview25 = findViewById(R.id.textview25);
		circleimageview23 = findViewById(R.id.circleimageview23);
		poin2 = findViewById(R.id.poin2);
		linear42 = findViewById(R.id.linear42);
		textview26 = findViewById(R.id.textview26);
		circleimageview25 = findViewById(R.id.circleimageview25);
		point3 = findViewById(R.id.point3);
		linear44 = findViewById(R.id.linear44);
		textview27 = findViewById(R.id.textview27);
		circleimageview27 = findViewById(R.id.circleimageview27);
		point4 = findViewById(R.id.point4);
		vscroll2 = findViewById(R.id.vscroll2);
		linear46 = findViewById(R.id.linear46);
		linear47 = findViewById(R.id.linear47);
		cardview1 = findViewById(R.id.cardview1);
		cardview2 = findViewById(R.id.cardview2);
		s1 = findViewById(R.id.s1);
		imageview4 = findViewById(R.id.imageview4);
		add = findViewById(R.id.add);
		linear51 = findViewById(R.id.linear51);
		textview28 = findViewById(R.id.textview28);
		s2 = findViewById(R.id.s2);
		imageview5 = findViewById(R.id.imageview5);
		c1 = findViewById(R.id.c1);
		linear52 = findViewById(R.id.linear52);
		textview29 = findViewById(R.id.textview29);
		b1 = findViewById(R.id.b1);
		b2 = findViewById(R.id.b2);
		b3 = findViewById(R.id.b3);
		d1 = new AlertDialog.Builder(this);
		frag = new FragFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		
		lin_search.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				/**/
				/*
new SearchsDialogFragmentActivity().show(getSupportFragmentManager(), "SOME_TAG");
*/
				startActivity(new Intent(ChatActivity.this, SearchActivity.class)); Animatoo.animateSlideUp(ChatActivity.this);
			}
		});
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MuneActivity.class);
				startActivity(i);
			}
		});
		
		cam.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				insta.setAction(Intent.ACTION_VIEW);
				insta.setData(Uri.parse("https://www.instagram.com/alex1.1111111111111111/"));
				startActivity(insta);
			}
		});
		
		edit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				face.setAction(Intent.ACTION_VIEW);
				face.setData(Uri.parse("https://www.facebook.com/alex1.1111111111111111111"));
				startActivity(face);
			}
		});
		
		linear8.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				/*لتعريف البوتوم شيت*/
				final com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = new com.google.android.material.bottomsheet.BottomSheetDialog(ChatActivity.this);
				
				View bottomSheetView; bottomSheetView = getLayoutInflater().inflate(R.layout.bot_cus,null );
				bottomSheetDialog.setContentView(bottomSheetView);
				
				bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(android.R.color.transparent);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout bg = (LinearLayout) bottomSheetView.findViewById(R.id.bg);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout lin = (LinearLayout) bottomSheetView.findViewById(R.id.lin);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear1 = (LinearLayout) bottomSheetView.findViewById(R.id.linear1);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear2 = (LinearLayout) bottomSheetView.findViewById(R.id.linear2);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear3 = (LinearLayout) bottomSheetView.findViewById(R.id.linear3);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear4 = (LinearLayout) bottomSheetView.findViewById(R.id.linear4);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear5 = (LinearLayout) bottomSheetView.findViewById(R.id.linear5);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear6 = (LinearLayout) bottomSheetView.findViewById(R.id.linear6);
				/*لتعريف اي شئ مثل نص او لينير*/
				LinearLayout linear7 = (LinearLayout) bottomSheetView.findViewById(R.id.linear7);
				int[] colorsHXVHJ = { Color.parseColor("#282828"), Color.parseColor(25) }; android.graphics.drawable.GradientDrawable HXVHJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsHXVHJ);
				HXVHJ.setCornerRadii(new float[]{(int)25,(int)25,(int)0,(int)0,(int)0,(int)0,(int)0,(int)0});
				HXVHJ.setStroke((int) "#000000", Color.parseColor(0));
				 .setElevation((float) bg);
				 .setBackground(HXVHJ);
				int[] colorsHDJJF = { Color.parseColor("#505050"), Color.parseColor(50) }; android.graphics.drawable.GradientDrawable HDJJF = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsHDJJF);
				HDJJF.setCornerRadii(new float[]{(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)0,(int)0});
				HDJJF.setStroke((int) "#000000", Color.parseColor(0));
				 .setElevation((float) lin);
				 .setBackground(HDJJF);
				/*عند الضغط يحدث حدث*/
				linear1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				linear2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				linear3.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				linear4.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				linear5.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				linear6.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*عند الضغط يحدث حدث*/
				linear7.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){
						/*اخفاء*/
						bottomSheetDialog.dismiss();
					}
				});
				/*اظهار*/
				bottomSheetDialog.show();
				return true;
			}
		});
		
		linear10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				chat.setClass(getApplicationContext(), ChatUsersActivity.class);
				startActivity(chat);
			}
		});
		
		imageview5.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				/*ده لتعريف الكاستم ديالوج و بنائة*/
				final AlertDialog d1 = new AlertDialog.Builder(ChatActivity.this).create();
				View inflate = getLayoutInflater().inflate(R.layout.dia_cus,null); 
				d1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
				d1.setView(inflate);
				/*ده لتعريف الباك جروند الي هو اللينير او اي لينير*/
				inflate.findViewById(R.id.bg);
				final LinearLayout bg = (LinearLayout)
				inflate.findViewById(R.id.bg);
				/*ده لتعريف الباك جروند الي هو اللينير او اي لينير*/
				inflate.findViewById(R.id.lin1);
				final LinearLayout lin1 = (LinearLayout)
				inflate.findViewById(R.id.lin1);
				/*ده لتعريف الباك جروند الي هو اللينير او اي لينير*/
				inflate.findViewById(R.id.lin2);
				final LinearLayout lin2 = (LinearLayout)
				inflate.findViewById(R.id.lin2);
				/*ده لتعريف الباك جروند الي هو اللينير او اي لينير*/
				inflate.findViewById(R.id.lin3);
				final LinearLayout lin3 = (LinearLayout)
				inflate.findViewById(R.id.lin3);
				int[] colorsJHDNE = { Color.parseColor("#FF282828"), Color.parseColor(20) }; android.graphics.drawable.GradientDrawable JHDNE = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsJHDNE);
				JHDNE.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)0,(int)0});
				JHDNE.setStroke((int) "#000000", Color.parseColor(2));
				 .setElevation((float) bg);
				 .setBackground(JHDNE);
				/*عند الضغط يحدث شئ*/
				lin1.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View _view){
						/*اخفاء الديالوج*/
						d1.dismiss();
					}
				});
				/*عند الضغط يحدث شئ*/
				lin2.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View _view){
						/*اخفاء الديالوج*/
						d1.dismiss();
					}
				});
				/*عند الضغط يحدث شئ*/
				lin3.setOnClickListener(new View.OnClickListener(){
							@Override
							public void onClick(View _view){
						/*اخفاء الديالوج*/
						d1.dismiss();
					}
				});
				/*اظهار الديالوج*/
				d1.show();
				return true;
			}
		});
		
		b1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				b1.setBackgroundResource(R.drawable.bottoms_1);
				b2.setBackgroundResource(R.drawable.bottoms_3);
				b3.setBackgroundResource(R.drawable.bottoms_2);
				edit.setImageResource(R.drawable.ic_edit_white);
				lin_search.setVisibility(View.VISIBLE);
				cam.setVisibility(View.VISIBLE);
				edit.setVisibility(View.VISIBLE);
				lin1.setVisibility(View.VISIBLE);
				lin2.setVisibility(View.GONE);
				lin3.setVisibility(View.GONE);
				textview1.setText("Chats");
			}
		});
		
		b2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				b1.setBackgroundResource(R.drawable.bottoms_4_3);
				b2.setBackgroundResource(R.drawable.bottoms_4_1);
				b3.setBackgroundResource(R.drawable.bottoms_2);
				edit.setImageResource(R.drawable.ic_perm_contact_cal_white);
				lin_search.setVisibility(View.GONE);
				edit.setVisibility(View.VISIBLE);
				lin2.setVisibility(View.VISIBLE);
				cam.setVisibility(View.GONE);
				lin1.setVisibility(View.GONE);
				lin3.setVisibility(View.GONE);
				textview1.setText("People");
			}
		});
		
		b3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				b1.setBackgroundResource(R.drawable.bottoms_4_3);
				b3.setBackgroundResource(R.drawable.bottoms_4_2);
				b2.setBackgroundResource(R.drawable.bottoms_3);
				lin_search.setVisibility(View.GONE);
				lin3.setVisibility(View.VISIBLE);
				cam.setVisibility(View.GONE);
				edit.setVisibility(View.GONE);
				lin1.setVisibility(View.GONE);
				lin2.setVisibility(View.GONE);
				textview1.setText("Stories");
			}
		});
	}
	
	private void initializeLogic() {
		lin_search.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF383838));
		lin_search.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF383838));
		cam.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF383838));
		edit.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFF383838));
		add.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)360, 0xFFFFFFFF));
		/*
s1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, Color.TRANSPARENT));
s2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)90, Color.TRANSPARENT));
int[] colorsHEGSS = { Color.parseColor("#00000000"), Color.parseColor(90) }; android.graphics.drawable.GradientDrawable HEGSS = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsHEGSS);
HEGSS.setCornerRadii(new float[]{(int)90,(int)90,(int)90,(int)90,(int)90,(int)90,(int)0,(int)0});
HEGSS.setStroke((int) "#00000000", Color.parseColor(2));
 .setElevation((float) s1);
 .setBackground(HEGSS);
int[] colorsHDHID = { Color.parseColor("#00000000"), Color.parseColor(90) }; android.graphics.drawable.GradientDrawable HDHID = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsHDHID);
HDHID.setCornerRadii(new float[]{(int)90,(int)90,(int)90,(int)90,(int)90,(int)90,(int)0,(int)0});
HDHID.setStroke((int) "#00000000", Color.parseColor(2));
 .setElevation((float) s2);
 .setBackground(HDHID);
s1.setBackgroundResource(0);
s2.setBackgroundResource(R.drawable.profi_4);
*/
		point4.setBorderColor(0xFF000000);
		point3.setBorderColor(0xFF000000);
		point1.setBorderColor(0xFF000000);
		poin2.setBorderColor(0xFF000000);
		c1.setBorderWidth(4);
		circleimageview27.setBorderWidth(0);
		circleimageview25.setBorderWidth(0);
		circleimageview23.setBorderWidth(0);
		circleimageview18.setBorderWidth(0);
		circleimageview10.setBorderWidth(0);
		circleimageview13.setBorderWidth(0);
		circleimageview12.setBorderWidth(0);
		circleimageview11.setBorderWidth(0);
		circleimageview2.setBorderWidth(0);
		circleimageview3.setBorderWidth(0);
		circleimageview4.setBorderWidth(0);
		circleimageview5.setBorderWidth(0);
		circleimageview6.setBorderWidth(0);
		circleimageview7.setBorderWidth(0);
		circleimageview8.setBorderWidth(0);
		circleimageview9.setBorderWidth(0);
		circleimageview1.setBorderWidth(0);
		lin1.setVisibility(View.VISIBLE);
		point3.setBorderWidth(2);
		point4.setBorderWidth(2);
		point1.setBorderWidth(2);
		poin2.setBorderWidth(2);
		lin2.setVisibility(View.GONE);
		lin3.setVisibility(View.GONE);
		_removeScollBar(vscroll1);
		_removeScollBar(hscroll1);
		textview1.setTextSize((int)23);
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			internet.setVisibility(View.GONE);
		}
		else {
			internet.setVisibility(View.VISIBLE);
		}
		edittext1.setEnabled(false);
	}
	
	public class FragFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public FragFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			
			return null;
		}
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _clickAnimation(final View _view) {
		ScaleAnimation fade_in = new ScaleAnimation(0.9f, 1f, 0.9f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.7f);
		fade_in.setDuration(300);
		fade_in.setFillAfter(true);
		_view.startAnimation(fade_in);
	}
	
	
	public void _ICC(final ImageView _img, final String _c1, final String _c2) {
		_img.setImageTintList(new android.content.res.ColorStateList(new int[][] {{-android.R.attr.state_pressed},{android.R.attr.state_pressed}},new int[]{Color.parseColor(_c1), Color.parseColor(_c2)}));
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}