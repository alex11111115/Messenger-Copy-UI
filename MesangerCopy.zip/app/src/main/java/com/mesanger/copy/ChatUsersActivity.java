package com.mesanger.copy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ImageView;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import android.widget.ScrollView;
import androidx.cardview.widget.CardView;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import com.blogspot.atifsoftwares.animatoolib.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class ChatUsersActivity extends AppCompatActivity {
	
	private double DeferredImage = 0;
	private double CacheLoader = 0;
	private double cacheSize = 0;
	
	private LinearLayout main;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview2;
	private CircleImageView circleimageview1;
	private LinearLayout linear15;
	private ImageView imageview8;
	private ImageView imageview9;
	private ImageView imageview10;
	private TextView textview5;
	private TextView textview8;
	private ScrollView vscroll1;
	private LinearLayout linear16;
	private LinearLayout linear20;
	private LinearLayout linear17;
	private LinearLayout linear21;
	private LinearLayout linear9;
	private LinearLayout linear8;
	private LinearLayout linear14;
	private CircleImageView circleimageview5;
	private TextView textview9;
	private TextView textview11;
	private TextView textview10;
	private TextView textview12;
	private CircleImageView circleimageview6;
	private CardView cardview1;
	private LinearLayout linear22;
	private ImageView imageCache;
	private ImageView imageview12;
	private ImageView imageview13;
	private CircleImageView circleimageview2;
	private LinearLayout m1l;
	private TextView textview3;
	private LinearLayout m1rr;
	private LinearLayout m2r;
	private TextView textview2;
	private TextView textview1;
	private TextView textview4;
	private CircleImageView circleimageview3;
	private LinearLayout linear12;
	private CircleImageView circleimageview4;
	private LinearLayout m2lr;
	private LinearLayout m3l;
	private TextView textview7;
	private TextView textview6;
	private ImageView imageview4;
	private ImageView imageview6;
	private ImageView imageview5;
	private ImageView imageview7;
	private LinearLayout linear7;
	private ImageView imageview1;
	private EditText edittext1;
	private ImageView imageview3;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat_users);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		imageview2 = findViewById(R.id.imageview2);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear15 = findViewById(R.id.linear15);
		imageview8 = findViewById(R.id.imageview8);
		imageview9 = findViewById(R.id.imageview9);
		imageview10 = findViewById(R.id.imageview10);
		textview5 = findViewById(R.id.textview5);
		textview8 = findViewById(R.id.textview8);
		vscroll1 = findViewById(R.id.vscroll1);
		linear16 = findViewById(R.id.linear16);
		linear20 = findViewById(R.id.linear20);
		linear17 = findViewById(R.id.linear17);
		linear21 = findViewById(R.id.linear21);
		linear9 = findViewById(R.id.linear9);
		linear8 = findViewById(R.id.linear8);
		linear14 = findViewById(R.id.linear14);
		circleimageview5 = findViewById(R.id.circleimageview5);
		textview9 = findViewById(R.id.textview9);
		textview11 = findViewById(R.id.textview11);
		textview10 = findViewById(R.id.textview10);
		textview12 = findViewById(R.id.textview12);
		circleimageview6 = findViewById(R.id.circleimageview6);
		cardview1 = findViewById(R.id.cardview1);
		linear22 = findViewById(R.id.linear22);
		imageCache = findViewById(R.id.imageCache);
		imageview12 = findViewById(R.id.imageview12);
		imageview13 = findViewById(R.id.imageview13);
		circleimageview2 = findViewById(R.id.circleimageview2);
		m1l = findViewById(R.id.m1l);
		textview3 = findViewById(R.id.textview3);
		m1rr = findViewById(R.id.m1rr);
		m2r = findViewById(R.id.m2r);
		textview2 = findViewById(R.id.textview2);
		textview1 = findViewById(R.id.textview1);
		textview4 = findViewById(R.id.textview4);
		circleimageview3 = findViewById(R.id.circleimageview3);
		linear12 = findViewById(R.id.linear12);
		circleimageview4 = findViewById(R.id.circleimageview4);
		m2lr = findViewById(R.id.m2lr);
		m3l = findViewById(R.id.m3l);
		textview7 = findViewById(R.id.textview7);
		textview6 = findViewById(R.id.textview6);
		imageview4 = findViewById(R.id.imageview4);
		imageview6 = findViewById(R.id.imageview6);
		imageview5 = findViewById(R.id.imageview5);
		imageview7 = findViewById(R.id.imageview7);
		linear7 = findViewById(R.id.linear7);
		imageview1 = findViewById(R.id.imageview1);
		edittext1 = findViewById(R.id.edittext1);
		imageview3 = findViewById(R.id.imageview3);
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < _charSeq.length()) {
					imageview4.setVisibility(View.GONE);
					imageview5.setVisibility(View.GONE);
					imageview6.setVisibility(View.GONE);
					imageview7.setVisibility(View.VISIBLE);
					imageview7.setImageResource(R.drawable.ic_chevron_right_white);
					imageview1.setImageResource(R.drawable.ic_send_white);
					imageview3.setImageResource(R.drawable.ic_pageview_white);
					imageview7.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
							imageview4.setVisibility(View.VISIBLE);
							imageview5.setVisibility(View.VISIBLE);
							imageview6.setVisibility(View.VISIBLE);
							imageview7.setVisibility(View.VISIBLE);
							imageview7.setImageResource(R.drawable.ic_mic_white);
						}
					});
				}
				else {
					imageview4.setVisibility(View.VISIBLE);
					imageview5.setVisibility(View.VISIBLE);
					imageview6.setVisibility(View.VISIBLE);
					imageview7.setVisibility(View.VISIBLE);
					imageview7.setImageResource(R.drawable.ic_mic_white);
					imageview1.setImageResource(R.drawable.ic_thumb_up_white);
					imageview3.setImageResource(R.drawable.ic_mood_white);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
	}
	
	private void initializeLogic() {
		imageview1.setColorFilter(0xFF0878E8);
		imageview2.setColorFilter(0xFF0878E8);
		imageview3.setColorFilter(0xFF0878E8);
		imageview4.setColorFilter(0xFF0878E8);
		imageview5.setColorFilter(0xFF0878E8);
		imageview6.setColorFilter(0xFF0878E8);
		imageview7.setColorFilter(0xFF0878E8);
		imageview8.setColorFilter(0xFF0878E8);
		imageview9.setColorFilter(0xFF0878E8);
		imageview10.setColorFilter(0xFF0878E8);
		edittext1.setMaxLines((int)6);
		int[] colorsJHDJD = { Color.parseColor("#303030"), Color.parseColor(35) }; android.graphics.drawable.GradientDrawable JHDJD = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsJHDJD);
		JHDJD.setCornerRadii(new float[]{(int)35,(int)35,(int)35,(int)35,(int)35,(int)35,(int)0,(int)0});
		JHDJD.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) linear7);
		 .setBackground(JHDJD);
		int[] colorsFDGUF = { Color.parseColor("#303030"), Color.parseColor(25) }; android.graphics.drawable.GradientDrawable FDGUF = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsFDGUF);
		FDGUF.setCornerRadii(new float[]{(int)25,(int)25,(int)25,(int)25,(int)25,(int)25,(int)0,(int)0});
		FDGUF.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) textview12);
		 .setBackground(FDGUF);
		_removeScollBar(vscroll1);
		int[] colorsUDJDJ = { Color.parseColor("#303030"), Color.parseColor(50) }; android.graphics.drawable.GradientDrawable UDJDJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsUDJDJ);
		UDJDJ.setCornerRadii(new float[]{(int)50,(int)50,(int)50,(int)50,(int)50,(int)50,(int)0,(int)0});
		UDJDJ.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) m1l);
		 .setBackground(UDJDJ);
		int[] colorsKDNJD = { Color.parseColor("#303030"), Color.parseColor(35) }; android.graphics.drawable.GradientDrawable KDNJD = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsKDNJD);
		KDNJD.setCornerRadii(new float[]{(int)35,(int)35,(int)35,(int)35,(int)35,(int)35,(int)0,(int)0});
		KDNJD.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) m3l);
		 .setBackground(KDNJD);
		int[] colorsKDJDN = { Color.parseColor("#0878E8"), Color.parseColor(35) }; android.graphics.drawable.GradientDrawable KDJDN = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsKDJDN);
		KDJDN.setCornerRadii(new float[]{(int)35,(int)35,(int)35,(int)35,(int)35,(int)35,(int)0,(int)0});
		KDJDN.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) m2r);
		 .setBackground(KDJDN);
		int[] colorsIDJEJ = { Color.parseColor("#BB282828"), Color.parseColor(35) }; android.graphics.drawable.GradientDrawable IDJEJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsIDJEJ);
		IDJEJ.setCornerRadii(new float[]{(int)35,(int)35,(int)35,(int)35,(int)35,(int)35,(int)0,(int)0});
		IDJEJ.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) m2lr);
		 .setBackground(IDJEJ);
		int[] colorsISSHX = { Color.parseColor("#BB282828"), Color.parseColor(35) }; android.graphics.drawable.GradientDrawable ISSHX = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsISSHX);
		ISSHX.setCornerRadii(new float[]{(int)35,(int)35,(int)35,(int)35,(int)35,(int)35,(int)0,(int)0});
		ISSHX.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) m1rr);
		 .setBackground(ISSHX);
		imageview12.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xBB555555));
		imageview13.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xBB555555));
		if (imageCache.getHeight() > imageCache.getWidth()) {
			imageCache.setMaxHeight((int)300);
			imageCache.setMaxWidth((int)200);
		}
		else {
			if (imageCache.getWidth() > imageCache.getHeight()) {
				imageCache.setMaxHeight((int)200);
				imageCache.setMaxWidth((int)300);
			}
			else {
				if (imageCache.getWidth() == imageCache.getHeight()) {
					imageCache.setMaxWidth((int)200);
					imageCache.setMaxHeight((int)200);
				}
			}
		}
		if (cardview1.getHeight() > cardview1.getWidth()) {
			/*
cardview1.setMaxHeight(300);
cardview1.setMaxWidth(200);
*/
		}
		else {
			if (cardview1.getWidth() > cardview1.getHeight()) {
				/*
cardview1.setMaxHeight(200);
cardview1.setMaxWidth(300);
*/
			}
			else {
				if (cardview1.getWidth() == cardview1.getHeight()) {
					/*
cardview1.setMaxWidth(200);
cardview1.setMaxHeight(200);
*/
				}
			}
		}
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}