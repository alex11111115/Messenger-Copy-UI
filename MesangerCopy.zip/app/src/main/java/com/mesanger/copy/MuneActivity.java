package com.mesanger.copy;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import de.hdodenhof.circleimageview.*;
import android.widget.ImageView;
import com.blogspot.atifsoftwares.animatoolib.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class MuneActivity extends AppCompatActivity {
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear6;
	private LinearLayout linear91;
	private LinearLayout linear103;
	private LinearLayout linear3;
	private TextView textview1;
	private CircleImageView circleimageview1;
	private ImageView cam;
	private TextView textview2;
	private LinearLayout linear5;
	private CircleImageView circleimageview3;
	private TextView textview3;
	private CircleImageView circleimageview4;
	private TextView textview4;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private CircleImageView circleimageview5;
	private LinearLayout linear9;
	private TextView textview5;
	private TextView textview10;
	private CircleImageView circleimageview7;
	private TextView textview6;
	private CircleImageView circleimageview9;
	private LinearLayout linear13;
	private TextView textview8;
	private TextView textview12;
	private CircleImageView circleimageview10;
	private LinearLayout linear15;
	private TextView textview9;
	private TextView textview11;
	private TextView textview42;
	private LinearLayout linear92;
	private LinearLayout linear93;
	private LinearLayout linear94;
	private LinearLayout linear95;
	private LinearLayout linear96;
	private LinearLayout linear97;
	private LinearLayout linear98;
	private LinearLayout linear99;
	private LinearLayout linear100;
	private LinearLayout linear101;
	private LinearLayout linear102;
	private CircleImageView circleimageview22;
	private TextView textview43;
	private CircleImageView circleimageview23;
	private TextView textview44;
	private CircleImageView circleimageview24;
	private TextView textview45;
	private CircleImageView circleimageview25;
	private TextView textview46;
	private CircleImageView circleimageview26;
	private TextView textview47;
	private CircleImageView circleimageview27;
	private TextView textview48;
	private CircleImageView circleimageview28;
	private TextView textview49;
	private CircleImageView circleimageview29;
	private TextView textview50;
	private CircleImageView circleimageview30;
	private TextView textview51;
	private CircleImageView circleimageview31;
	private TextView textview52;
	private CircleImageView circleimageview32;
	private TextView textview53;
	private TextView textview54;
	private LinearLayout linear104;
	private LinearLayout linear105;
	private LinearLayout linear106;
	private LinearLayout linear107;
	private CircleImageView circleimageview33;
	private TextView textview55;
	private CircleImageView circleimageview34;
	private TextView textview56;
	private CircleImageView circleimageview35;
	private TextView textview57;
	private CircleImageView circleimageview36;
	private TextView textview58;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.mune);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		linear6 = findViewById(R.id.linear6);
		linear91 = findViewById(R.id.linear91);
		linear103 = findViewById(R.id.linear103);
		linear3 = findViewById(R.id.linear3);
		textview1 = findViewById(R.id.textview1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		cam = findViewById(R.id.cam);
		textview2 = findViewById(R.id.textview2);
		linear5 = findViewById(R.id.linear5);
		circleimageview3 = findViewById(R.id.circleimageview3);
		textview3 = findViewById(R.id.textview3);
		circleimageview4 = findViewById(R.id.circleimageview4);
		textview4 = findViewById(R.id.textview4);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		circleimageview5 = findViewById(R.id.circleimageview5);
		linear9 = findViewById(R.id.linear9);
		textview5 = findViewById(R.id.textview5);
		textview10 = findViewById(R.id.textview10);
		circleimageview7 = findViewById(R.id.circleimageview7);
		textview6 = findViewById(R.id.textview6);
		circleimageview9 = findViewById(R.id.circleimageview9);
		linear13 = findViewById(R.id.linear13);
		textview8 = findViewById(R.id.textview8);
		textview12 = findViewById(R.id.textview12);
		circleimageview10 = findViewById(R.id.circleimageview10);
		linear15 = findViewById(R.id.linear15);
		textview9 = findViewById(R.id.textview9);
		textview11 = findViewById(R.id.textview11);
		textview42 = findViewById(R.id.textview42);
		linear92 = findViewById(R.id.linear92);
		linear93 = findViewById(R.id.linear93);
		linear94 = findViewById(R.id.linear94);
		linear95 = findViewById(R.id.linear95);
		linear96 = findViewById(R.id.linear96);
		linear97 = findViewById(R.id.linear97);
		linear98 = findViewById(R.id.linear98);
		linear99 = findViewById(R.id.linear99);
		linear100 = findViewById(R.id.linear100);
		linear101 = findViewById(R.id.linear101);
		linear102 = findViewById(R.id.linear102);
		circleimageview22 = findViewById(R.id.circleimageview22);
		textview43 = findViewById(R.id.textview43);
		circleimageview23 = findViewById(R.id.circleimageview23);
		textview44 = findViewById(R.id.textview44);
		circleimageview24 = findViewById(R.id.circleimageview24);
		textview45 = findViewById(R.id.textview45);
		circleimageview25 = findViewById(R.id.circleimageview25);
		textview46 = findViewById(R.id.textview46);
		circleimageview26 = findViewById(R.id.circleimageview26);
		textview47 = findViewById(R.id.textview47);
		circleimageview27 = findViewById(R.id.circleimageview27);
		textview48 = findViewById(R.id.textview48);
		circleimageview28 = findViewById(R.id.circleimageview28);
		textview49 = findViewById(R.id.textview49);
		circleimageview29 = findViewById(R.id.circleimageview29);
		textview50 = findViewById(R.id.textview50);
		circleimageview30 = findViewById(R.id.circleimageview30);
		textview51 = findViewById(R.id.textview51);
		circleimageview31 = findViewById(R.id.circleimageview31);
		textview52 = findViewById(R.id.textview52);
		circleimageview32 = findViewById(R.id.circleimageview32);
		textview53 = findViewById(R.id.textview53);
		textview54 = findViewById(R.id.textview54);
		linear104 = findViewById(R.id.linear104);
		linear105 = findViewById(R.id.linear105);
		linear106 = findViewById(R.id.linear106);
		linear107 = findViewById(R.id.linear107);
		circleimageview33 = findViewById(R.id.circleimageview33);
		textview55 = findViewById(R.id.textview55);
		circleimageview34 = findViewById(R.id.circleimageview34);
		textview56 = findViewById(R.id.textview56);
		circleimageview35 = findViewById(R.id.circleimageview35);
		textview57 = findViewById(R.id.textview57);
		circleimageview36 = findViewById(R.id.circleimageview36);
		textview58 = findViewById(R.id.textview58);
	}
	
	private void initializeLogic() {
		setTitle("Me");
		int[] colorsJSHDJ = { Color.parseColor("#383838"), Color.parseColor(360) }; android.graphics.drawable.GradientDrawable JSHDJ = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation. , colorsJSHDJ);
		JSHDJ.setCornerRadii(new float[]{(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)10,(int)10});
		JSHDJ.setStroke((int) "#000000", Color.parseColor(0));
		 .setElevation((float) cam);
		 .setBackground(JSHDJ);
		circleimageview1.setBorderWidth(0);
		circleimageview3.setBorderWidth(0);
		circleimageview4.setBorderWidth(0);
		circleimageview5.setBorderWidth(0);
		circleimageview7.setBorderWidth(0);
		circleimageview9.setBorderWidth(0);
		circleimageview10.setBorderWidth(0);
		circleimageview22.setBorderWidth(0);
		circleimageview23.setBorderWidth(0);
		circleimageview24.setBorderWidth(0);
		circleimageview25.setBorderWidth(0);
		circleimageview26.setBorderWidth(0);
		circleimageview27.setBorderWidth(0);
		circleimageview28.setBorderWidth(0);
		circleimageview29.setBorderWidth(0);
		circleimageview30.setBorderWidth(0);
		circleimageview31.setBorderWidth(0);
		circleimageview32.setBorderWidth(0);
		circleimageview33.setBorderWidth(0);
		circleimageview34.setBorderWidth(0);
		circleimageview35.setBorderWidth(0);
		circleimageview36.setBorderWidth(0);
		_removeScollBar(vscroll1);
		/**/
		/*

int[] colorsGDSJD = { Color.parseColor(#383838), Color.parseColor(#383838) }; android.graphics.drawable.GradientDrawable GDSJD = new a
ndroid.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors GDSJD);
	GDSJD.setCornerRadii(new float[]{(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)360,(int)360});
	GDSJD.setStroke((int) 29, Color.parseColor(#FF000000));
	cam.setElevation((float) 0);
	cam.setBackground(GDSJD);

*/
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}